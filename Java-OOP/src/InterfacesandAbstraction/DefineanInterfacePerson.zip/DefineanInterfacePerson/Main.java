package DefineanInterfacePerson;

public class Main {
}
