package MultipleImplementation;

public class Main {
}
