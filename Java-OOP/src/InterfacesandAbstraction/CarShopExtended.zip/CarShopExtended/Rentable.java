package CarShopExtended;

public interface Rentable {
    Integer getMinRentDay();
    Double getPricePerDay();
}
