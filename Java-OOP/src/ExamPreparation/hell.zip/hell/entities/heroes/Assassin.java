package hell.entities.heroes;

public class Assassin extends BaseHero{
    public Assassin(String name) {
        super(name, 25, 100, 15, 150, 300);
    }
}
