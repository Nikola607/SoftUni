package WorkingWithAbstraction.SortByNameAndAge;

import java.util.Collections;
import java.util.List;

public class Person {
    private String firstName;
    private String lastName;
    private int age;

    public Person(String firstName, String lastName, int age) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getAge() {
        return age;
    }

    public String toString(List<Person> people) {
        return String.format("%s %s is %s years old.",getFirstName(), getLastName(), getAge());
    }
}
