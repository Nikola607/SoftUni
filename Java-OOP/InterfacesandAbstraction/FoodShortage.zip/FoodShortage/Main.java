package FoodShortage;

public class Main {
}
