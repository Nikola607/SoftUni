package aquarium.entities.aquariums;

public class SaltwaterAquarium extends BaseAquarium{
    public SaltwaterAquarium(String name) {
        super(name, 25);
    }
}
