package WildFarm;

public abstract class Mammal extends Animal{
    public Mammal(String name, String type, double weight, String livingRegion) {
        super(name, type, weight, livingRegion);
    }
}
