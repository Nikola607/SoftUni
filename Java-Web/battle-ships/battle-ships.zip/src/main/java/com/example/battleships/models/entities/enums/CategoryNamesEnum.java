package com.example.battleships.models.entities.enums;

public enum CategoryNamesEnum {
    BATTLE, CARGO, PATROL
}
